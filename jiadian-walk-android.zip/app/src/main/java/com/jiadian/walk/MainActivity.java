package com.jiadian.walk;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

/**
 * 整個 App 只有這一頁：用 WebView 顯示 assets/index.html（遊戲本體），
 * 另外提供兩件網頁自己做不到的事：
 *   1. 讀手機的計步感測器，把數字傳給網頁（window.onNativeSteps）。
 *   2. 讓網頁裡的「加入照片」按鈕能打開手機的相片選擇器。
 */
public class MainActivity extends Activity implements SensorEventListener {

    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final int REQ_PERMISSION = 1;
    private static final int REQ_FILE = 2;

    private WebView web;
    private SensorManager sensors;
    private Sensor stepCounter;
    private boolean wantSteps = false;
    private boolean listening = false;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // 讓 localStorage / IndexedDB 可以保存紀錄與照片
        s.setAllowFileAccess(false);

        // 把 assets 資料夾當成一個 https 網站來載入，網頁的儲存功能才會正常運作
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // 不讓 App 跳到外部網站
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(pick, "選擇照片"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidSteps");

        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepCounter = sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        web.loadUrl(HOME);
    }

    /** 網頁用 AndroidSteps.start() 呼叫這裡。 */
    private class Bridge {
        @JavascriptInterface
        public void start() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() { startSteps(); }
            });
        }
    }

    private boolean hasStepPermission() {
        return Build.VERSION.SDK_INT < 29
                || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void startSteps() {
        wantSteps = true;
        if (stepCounter == null) {
            tellState("nosensor");
            return;
        }
        if (!hasStepPermission()) {
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ_PERMISSION);
            return;
        }
        listen();
    }

    private void listen() {
        if (!listening) {
            listening = sensors.registerListener(this, stepCounter, SensorManager.SENSOR_DELAY_NORMAL);
        }
        tellState(listening ? "on" : "nosensor");
    }

    private void tellState(String state) {
        web.evaluateJavascript("window.onNativeStepState&&window.onNativeStepState('" + state + "')", null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        if (requestCode != REQ_PERMISSION) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) listen();
        else tellState("denied");
    }

    // 計步感測器回報的是「開機以來的總步數」；每天各走幾步由網頁那邊相減計算。
    @Override
    public void onSensorChanged(SensorEvent event) {
        long total = (long) event.values[0];
        web.evaluateJavascript("window.onNativeSteps&&window.onNativeSteps(" + total + ")", null);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    protected void onResume() {
        super.onResume();
        if (wantSteps && stepCounter != null && hasStepPermission()) listen();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (listening) {
            sensors.unregisterListener(this);
            listening = false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] picked = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null && clip.getItemCount() > 0) {
                picked = new Uri[clip.getItemCount()];
                for (int i = 0; i < picked.length; i++) picked[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                picked = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(picked);
        fileCallback = null;
    }
}
