# 家電散步隊 Android App

把網頁遊戲（`app/src/main/assets/index.html`）包成 Android App 的專案。
App 會讀手機內建的計步感測器，所以不用手動輸入步數。

注意：這個專案還沒有實際建置和在手機上測試過，第一次建置如果出現錯誤訊息，
把訊息貼給 Claude 就能繼續修。

## 方法一：用 GitHub 幫你建置（不用裝任何軟體）

1. 到 https://github.com 註冊帳號，按右上角 + → New repository，名稱隨意，選 Private，建立。
2. 在新的 repository 頁面按「uploading an existing file」，把這個資料夾裡的**所有檔案和資料夾**拖進去
   （包含 `.github` 資料夾；看不到的話請在檔案總管開啟「顯示隱藏的項目」），按 Commit changes。
3. 點上方的 Actions 分頁，會看到「Build APK」正在跑，大約 3 到 5 分鐘。
4. 跑完（綠色勾勾）後點進去，在最下面 Artifacts 下載 `jiadian-walk-apk`，解壓縮得到 `app-debug.apk`。
5. 把 APK 傳到手機（LINE 傳給自己、Google 雲端硬碟、USB 都可以），點它安裝。
   手機會問是否允許安裝未知來源的應用程式，選允許。
6. 第一次打開會問「身體活動」權限，選允許，才能自動計步。

## 方法二：用 Android Studio（想學 App 開發的話）

1. 安裝 Android Studio：https://developer.android.com/studio
2. File → Open，選這個資料夾，等它同步完成（第一次會下載不少東西）。
3. 手機開啟「開發人員選項」裡的「USB 偵錯」，用 USB 線接電腦，按上方綠色的 Run。

## 之後要改遊戲

只要換掉 `app/src/main/assets/index.html`，再重新建置、安裝即可。
專案內附固定的簽章檔（`keystore/debug.keystore`），所以新版可以直接覆蓋安裝，紀錄不會消失。

## 要知道的事

- 所有紀錄（步數、血壓、行事曆、日記、照片）都只存在這支手機的 App 裡。
  **解除安裝或清除 App 資料，紀錄就會消失。**
- 計步用的是手機的計步感測器。App 沒開的時候走的步數，會在下次打開時一次補上
  （會全部算在打開的那一天）。手機重開機前沒打開過 App 的那段步數會漏掉。
- 需要 Android 8.0 以上。
- 內附的簽章檔是公開的，只適合自己和朋友安裝用；要上架 Google Play 需要換成自己的金鑰。
